## Live at @https://next-js-application-with-firebase-authe-git-663d5c-priyanshu475.vercel.app/


#   Next.js-Application-with-Firebase-Authentication-and-GIPHY-API-Integration


# Next.js + Tailwind CSS + API Integration + Firebase

</br>
</br>


# Login/SignUp Home Page
![Screenshot from 2023-12-15 23-23-52](https://github.com/Priyanshu475/Next.js-Application-with-Firebase-Authentication-and-GIPHY-API-Integration/assets/96469123/9f7ee6ea-ef93-4b19-8f14-a730f2e320a0)

</br>
</br>

# GIF Search Bar
![Screenshot from 2023-12-15 23-24-25](https://github.com/Priyanshu475/Next.js-Application-with-Firebase-Authentication-and-GIPHY-API-Integration/assets/96469123/5b48a619-3302-4719-ae86-f9a5cfd8961c)


</br>
</br>


![Screenshot from 2023-12-15 23-25-11](https://github.com/Priyanshu475/Next.js-Application-with-Firebase-Authentication-and-GIPHY-API-Integration/assets/96469123/6febb34f-2cf0-41ae-a924-fc98c1690f76)

# Thank You !!

